import { Component } from '@angular/core';

@Component({
  selector: 'app-tc-roi',
  templateUrl: './tc-roi.component.html',
  styleUrls: ['./tc-roi.component.css']
})
export class TcRoiComponent {

}
