import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup, NgForm, Validators } from "@angular/forms";
import { Router } from "@angular/router";
import { ServerService } from "../Services/server.service";
import crypto from "crypto-js";
// import * as FingerprintJS from 'fingerprintjs2';
import { LoginService } from './login.service'
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { v4 as uuidv4 } from 'uuid';
import { HttpHeaders } from "@angular/common/http";


@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"],
})
export class LoginComponent implements OnInit {
  // private fingerprintPromise: Promise<string>;
  // private fingerprint: string;
  userIsAdmin:boolean = false
  userIsUser:boolean = false
  userName: string = "";
  password: any;
  token:any
  secretKey: string = "docketrun@123"; 
  credentials: any[] = [
    { userName: "admin", password: "admin@123" },
    { userName: "user1", password: "user1@123" },
    { userName: "user2", password: "user2@123" },
  ];
   // constructor() {
  //   this.uniqueId = uuidv4();

  fail: boolean = false;
  isLoading: boolean = false;
  OTP:any
  captcha: string;
  userInput: string;
  OTPVerified :boolean = false
  gotOTP:boolean = false
  uniqueId: string;
  Website :string=''
  jwtoken: string;
  emailid:string;

  AdminLoginForm: FormGroup = new FormGroup({
    emailid: new FormControl("", Validators.required),
    password: new FormControl("", Validators.required),
    token:new FormControl("",Validators.required),
  })

  ChangePasswordForm: FormGroup = new FormGroup({
    currentPassword: new FormControl("", Validators.required),
    newPassword: new FormControl("", Validators.required),
    confirmPassword:new FormControl("",Validators.required),
  })

  ForgottenPasswordForm: FormGroup = new FormGroup({
    emailid: new FormControl("", Validators.required),
    userInput:new FormControl("",Validators.required),
     forgottenNewPassword: new FormControl("", Validators.required),
     forgottenConfirmPassword:new FormControl("",Validators.required),
  })

  UserLoginForm: FormGroup = new FormGroup({
    emailid: new FormControl("", Validators.required),
    password: new FormControl("", Validators.required),
    token:new FormControl("",Validators.required),
  })


  constructor(
    private Router: Router, 
    private Server: ServerService,
    private service:LoginService,
    public modalService: NgbModal,
    ) {
      this.uniqueId = uuidv4();
      // console.log(this.uniqueId,"this is uniqueId from the login page")
      // this.generateRandomString(6)
      this.captcha = this.generateRandomString(6);
  }

  CreateAccount(){
    this.Router.navigate(['/create-account'])
  }

  // async logAction(user: any, action: string, data?: any): Promise<void> {
  //   const fingerprint = await this.getFingerprint();
  //   const browserInfo = this.getBrowserInfo();
  //   const logData = {
  //     user,
  //     action,
  //     data,
  //     fingerprint,
  //     browserInfo
  //   };
  //   // Here you would send logData to your server for storage
  //   console.log('Logged Action:', logData);
  // }

  // async getFingerprint(): Promise<string> {
  //   const fp = await this.fingerprintPromise;
  //   const result = await fp.get();
  //   return result.visitorId;
  // }

  // private getBrowserInfo(): string {
  //   return navigator.userAgent;
  // }

  ngOnInit(): void {

    // this.captcha = this.generateRandomString(6);

    const userAgent = navigator.userAgent;
    // console.log('User-Agent:', userAgent);

    if (userAgent.includes('Chrome') && !userAgent.includes('Edg')) {
      this.Website='Chrome'
      // console.log('Running in Chrome');
    } else if (userAgent.includes('Firefox')) {
      this.Website = 'Firefox'
      // console.log('Running in Firefox');
    } else if (userAgent.includes('Edg')) {
      this.Website = 'Edge'
      // console.log('Running in Edge');
    } else if (userAgent.includes('Safari')) {
      this.Website = 'Safari'
      // console.log('Running in Safari');
    } else {
      // console.log('Running in another browser')
      this.Website = 'Other browser'
    }
  }


  // logAction(action: string) {
  //   // Send the action to a backend server or store it locally
  //   console.log('User actions:', action);
  // }



  // logAction(actionType: string, data: any) {
  //   const timestamp = new Date().toISOString();
  //   console.log(`Action: ${actionType}, Timestamp: ${timestamp}, Data: `, data);
  //   // Here you can store the log data locally, send it to a backend server, or store it in a database
  // }

  // async generateFingerprint(): Promise<void> {
  //   try {
  //     this.fingerprint = await this.loginservice.generateFingerprint();
  //     console.log('Generated Fingerprint:', this.fingerprint);
  //   } catch (error) {
  //     console.error('Error generating fingerprint:', error);
  //   }
  // }
  
  OnSubmit(f: NgForm) {

    // this.Router.navigate(['/app/user-management']);
     this.isLoading = true;
     
    var data:any = {
      email:this.AdminLoginForm.value["emailid"],
      password:this.AdminLoginForm.value["password"],
      token:this.AdminLoginForm.value["token"]
    }
    // var data1 = crypto.AES.encrypt(data,this.secretKey)


    this.service.AdminLogin(data).subscribe((Response:any)=>
    {
      const jwtoken = Response.jwtoken; 
      localStorage.setItem('jwtoken', jwtoken);
      this.jwtoken = localStorage.getItem('jwtoken')
     this.Router.navigate(["app/user-management"]);
      
      // this.service.notification(Response.message)

      if(Response.success){
        this.userIsAdmin = true
        console.log('this is form the onadminsubmit success condition')
        // this.Router.navigate(['/app/user-management'])
        this.Server.GetJobSheet().subscribe((response: any) => {

                  this.isLoading = false;
                  if (response.job_sheet_status) {
                    this.Router.navigate(["app/jobsheetMoniter"]);
                  } else {
                    this.Router.navigate(["app/jobsheetUpload"]);
                  }
                },Err=>{
                  this.Router.navigate(["app/jobsheetUpload"]);
      
                });

                this.SendAdminLoginDetails()


               
      }
      else{
        // this.Router.navigate(["app/user-management"]);
        // console.log(this.jwtoken = Response.jwtoken)
        this.service.notification(Response.message)
      }

      
      

    })

    this.emailid = this.AdminLoginForm.value["emailid"],
    this.password = this.AdminLoginForm.value["password"],
    this.token = this.AdminLoginForm.value["token"]
    
    // var index = this.credentials.findIndex((data: any) => {
    //   return data.userName == this.userName;
    // });

    // if (index != -1) {
      // if (this.credentials[index].password == this.password) {
       
      // } else {
      //   this.isLoading = false;
      //   this.fail = true;
      // }
    // } else {
    //   this.isLoading = false;
    //   this.fail = true;
    // }



    try {
      console.log("logged in");
      var userData = JSON.stringify({
        emailid: this.emailid,
        password: this.password,
        userType: this.userIsAdmin?"admin":"user"
      });
      var encodedUserData = crypto.AES.encrypt(
        userData,
        this.Server.secretKey
      );
      sessionStorage.setItem("session", encodedUserData.toString());
      // this.Router.navigate(['/app/user-management']);
      this.Server.GetJobSheet().subscribe((response: any) => {

        this.isLoading = false;
        if (response.job_sheet_status) {
          this.Router.navigate(["app/jobsheetMoniter"]);
        } else {
          this.Router.navigate(["app/jobsheetUpload"]);
        }
      },Err=>{
        this.Router.navigate(["app/jobsheetUpload"]);

      });
      //this.Router.navigate(['app/jobsheetUpload'])
    } catch {
      this.Server.notification("error while logging  in");
    }

  }

  ToNextField(id:string){
      document?.getElementById(id).focus(); // get the sibling element
  }

  ChangePassword(modal:any){
    this.modalService.open(modal)
  }

  ForgottenPassword(modal:any){
    this.modalService.open(modal)
  }

  ChangePasswordSubmit(){
    var data:any = {
      current_password:this.ChangePasswordForm.value["currentPassword"],
      new_password:this.ChangePasswordForm.value["newPassword"],
      confirm_password:this.ChangePasswordForm.value["confirmPassword"]
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+ this.jwtoken
      })
    };
    this.service.ChangePassword(data,httpOptions).subscribe((Response:any)=>{
      this.Server.notification(Response.message)
    })
  }

  SendOTP(){
    var data:any = {
      email:this.ForgottenPasswordForm.value["emailid"]
    }

    this.service.SendOTP(data).subscribe((Response:any)=>{
      this.Server.notification(Response.message)
      this.OTP = Response.otp
      if(Response.success){
        this.gotOTP = true
      }
      else{
        this.gotOTP = false
      }
    })
  }


 generateRandomString(length: number): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return result;
}


verify() {
if (this.ForgottenPasswordForm.value['userInput'] == this.OTP+this.captcha){

  // console.log(this.ForgottenPasswordForm.value['userInput'],"this is user input")
  // console.log(this.OTP+this.captcha,"this is generated OTP")
  this.Server.notification('You have entered the correct OTP')
  this.OTPVerified = true

}
else{
  // console.log(this.ForgottenPasswordForm.value['userInput'],"this is user input from else condition")
  this.Server.notification(" Please Check the OTP You have entered Wrong OTP ")
  this.OTPVerified = false
}
 }

 ForgottenPasswordSubmit(){
  var data :any ={
    otp:this.ForgottenPasswordForm.value["userInput"],
    password:this.ForgottenPasswordForm.value["forgottenNewPassword"],
    confirm_password:this.ForgottenPasswordForm.value["forgottenConfirmPassword"],
    email:this.ForgottenPasswordForm.value["emailid"]

  }
    this.service.ForgottenPassword(data).subscribe((Response:any)=>{

      if(Response.success){
        this.Server.notification(Response.message)
        this.modalService.dismissAll()
      }
      else{
        this.Server.notification(Response.message)
      }
      

})
 }
 

 SendAdminLoginDetails(){
  var data :any = {
    browser:this.Website,
    systemid:this.uniqueId
  }

  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer '+ this.jwtoken
    })
  };
  this.service.SendAdminLogDetails(data,httpOptions).subscribe((response:any)=>
  {
    if(response.success){
      this.Server.notification(response.message)
    }
    
  })

 }



 UserLoginSubmit(f: NgForm) {

  console.log('this is the userloginsubmit function')

  // this.Router.navigate(['/app/user-management']);
   this.isLoading = true;
  var data:any = {
    email:this.UserLoginForm.value["emailid"],
    password:this.UserLoginForm.value["password"],
    token:this.UserLoginForm.value["token"]
  }



  this.service.UserLogin(data).subscribe((Response:any)=>
  {
    console.log('this is from the inside the service.userlogin function')
    const jwtoken = Response.jwtoken; 
    localStorage.setItem('jwtoken', jwtoken);
    this.jwtoken = localStorage.getItem('jwtoken')
   this.Router.navigate(["app/user-management"]);
    
    // this.service.notification(Response.message)

    if(Response.success){

     this.userIsUser = true

      var userData = JSON.stringify({
        emailid: this.emailid,
        password: this.password,
        userType: this.userIsUser?"user":"admin"
      });
      var encodedUserData = crypto.AES.encrypt(
        userData,
        this.Server.secretKey
      );
      sessionStorage.setItem("session", encodedUserData.toString());
       this.Router.navigate(['/app/user-management'])
      this.Server.GetJobSheet().subscribe((response: any) => {


                this.isLoading = false;
                if (response.job_sheet_status) {
                  this.Router.navigate(["app/jobsheetMoniter"]);
                } else {
                  this.Router.navigate(["app/jobsheetUpload"]);
                }
              },Err=>{
                this.Router.navigate(["app/jobsheetUpload"]);
    
              });

              // this.SendAdminLoginDetails()


             
    }
    else{
      // this.Router.navigate(["app/user-management"]);
      // console.log(this.jwtoken = Response.jwtoken)
      this.service.notification(Response.message)
    }

    
    

  })

  // this.emailid = this.UserLoginForm.value["emailid"],
  // this.password = this.UserLoginForm.value["password"],
  // this.token = this.UserLoginForm.value["token"]
  
  // var index = this.credentials.findIndex((data: any) => {
  //   return data.userName == this.userName;
  // });

  // if (index != -1) {
    // if (this.credentials[index].password == this.password) {
     
    // } else {
    //   this.isLoading = false;
    //   this.fail = true;
    // }
  // } else {
  //   this.isLoading = false;
  //   this.fail = true;
  // }



  // try {
  //   console.log("logged in");
  //   var userData = JSON.stringify({
  //     emailid: this.emailid,
  //     password: this.password,
  //     // userType: this.userName == "admin" ? "admin" : "user",
  //   });
  //   var encodedUserData = crypto.AES.encrypt(
  //     userData,
  //     this.Server.secretKey
  //   );
  //   sessionStorage.setItem("session", encodedUserData.toString());
  //   // this.Router.navigate(['/app/user-management']);
  //   this.Server.GetJobSheet().subscribe((response: any) => {

  //     this.isLoading = false;
  //     if (response.job_sheet_status) {
  //       this.Router.navigate(["app/jobsheetMoniter"]);
  //     } else {
  //       this.Router.navigate(["app/jobsheetUpload"]);
  //     }
  //   },Err=>{
  //     this.Router.navigate(["app/jobsheetUpload"]);

  //   });
  //   //this.Router.navigate(['app/jobsheetUpload'])
  // } catch {
  //   this.Server.notification("error while logging  in");
  // }

}

 
 ngOnDestory(){
  this.modalService.dismissAll()

 }

}



  

