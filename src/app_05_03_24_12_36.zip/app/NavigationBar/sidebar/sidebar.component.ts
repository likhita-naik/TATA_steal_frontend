import { HttpHeaders } from '@angular/common/http';
import { AfterViewInit, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ServerService } from 'src/app/Services/server.service';
import { SidebarService } from './sidebar.service';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})

export class SidebarComponent implements OnInit ,AfterViewInit{
   isCollapse:boolean=false
   adminProfileDetails:any
   jwtoken :string

   ChangePasswordForm: FormGroup = new FormGroup({
    currentPassword: new FormControl("", Validators.required),
    newPassword: new FormControl("", Validators.required),
    confirmPassword:new FormControl("",Validators.required),
  })

  EditProfileForm: FormGroup = new FormGroup({
    fullName: new FormControl("", Validators.required),
    contactNumber: new FormControl("", Validators.required),
    department:new FormControl("",Validators.required),
  })

  constructor(
    private router:Router,
    public server:ServerService,
    private ModalService:NgbModal,
    public service:SidebarService) 
    { 
      this.server.isCollapse.subscribe((value:any)=>{
        this.isCollapse=value
        console.log('iscollapse',this.isCollapse)
      })
   
      console.log(this.isCollapse,'collapse')

        this.jwtoken = localStorage.getItem('jwtoken')
        this.ViewAdminProfileDetails()
    }

  ngOnInit(): void {

  }

  ngAfterViewInit(): void {

    if(localStorage.getItem('isCollapse')=='true'){
      this.isCollapse=true
      var sidebarWrapper=document.getElementById('sidebarWrapper')
      var sidebar=document.getElementById('sidebar')
      var footer=document.getElementById('footer')
      var wrapper=document.getElementsByClassName('dashboard-wrapper')[0]
      sidebar.classList.toggle('active')
      footer.classList.toggle('active')
      wrapper.classList.toggle('active')
      this.server.isCollapse.next(true)
    }

    else{
      this.isCollapse=false
    }

  }


  Logout(){

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': 'Bearer '+ this.jwtoken
      })
    };

    sessionStorage.removeItem('session')

    this.service.AdminLogout(httpOptions).subscribe((Response:any)=>
    {
      if(Response.success){
        this.ModalService.dismissAll()
        this.service.notification(Response.message)
      }
      else{
        this.ModalService.dismissAll()
      }
      
    })

    this.router.navigate(['/login']) 
}


OpenLogoutModal(modal:any){
  this.ModalService.open(modal,{centered:true,backdrop:'static'})
}


toggleSidebar(){
  this.isCollapse=!this.isCollapse
  localStorage.setItem('isCollapse','true')
  var sidebarWrapper=document.getElementById('sidebarWrapper')
  var sidebar=document.getElementById('sidebar')
  var footer=document.getElementById('footer')
  var wrapper=document.getElementsByClassName('dashboard-wrapper')[0]
  console.log(wrapper)
  sidebar.classList.toggle('active')
  footer.classList.toggle('active')
  wrapper.classList.toggle('active')
  this.server.isCollapse.next(this.isCollapse)
}


OpenChangePassword(modal:any){
  this.ModalService.dismissAll()
  this.ModalService.open(modal)
}

ChangePasswordSubmit(){
  var data:any = {
    current_password:this.ChangePasswordForm.value["currentPassword"],
    new_password:this.ChangePasswordForm.value["newPassword"],
    confirm_password:this.ChangePasswordForm.value["confirmPassword"]
  }

  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer '+ this.jwtoken
    })
  };

  this.service.ChangePassword(data,httpOptions).subscribe((Response:any)=>{

    if(Response.success){
      this.ModalService.dismissAll()
      this.server.notification(Response.message)
    }
    else{

    }
    
  })
}


OpenUpdateProfileModal(modal:any){

  this.EditProfileForm.patchValue({
  fullName: this.adminProfileDetails.fullname,
  department: this.adminProfileDetails.department,
  contactNumber: this.adminProfileDetails.contact
});

  this.ModalService.dismissAll()
  this.ModalService.open(modal)
}

OpenViewAdminProfileModal(modal:any){
  this.ModalService.open(modal)
}

UpdateProfileSubmit(){
  var data:any = {
    fullname:this.EditProfileForm.value["fullName"],
    department:this.EditProfileForm.value["department"],
    contact:this.EditProfileForm.value["contactNumber"]
  }

  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer '+ this.jwtoken
    })
  };
this.service.UpdateAdminProfile(data,httpOptions).subscribe((response:any)=>
{
  if(response.success){
    this.ModalService.dismissAll()
    this.service.notification(response.message)
    this.ViewAdminProfileDetails()
  }
  else{

  }
 
})

}


ViewAdminProfileDetails(){

  const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer '+ this.jwtoken
    })
  };

  this.service.AdminProfileDetails(httpOptions).subscribe((Response:any)=>
  {
    if(Response.success){
      this.adminProfileDetails = Response.message
    }
    else{
      this.ModalService.dismissAll()
      this.service.notification(Response.message)
    }
  })
}


}
