// import 'fabric'
// declare const fabric:any
// interface CustomFabricProps {
//     id ?: string;
//   }
//   export type CustomFabricObject = fabric.Object & {id?:string};
//   export type CustomFabricRect = fabric.Rect & CustomFabricProps;
//   export type CustomFabricEllipse = fabric.Ellipse & CustomFabricProps;
//   export type CustomFabricLine = fabric.Line & CustomFabricProps;
//   export type CustomFabricPolygon = fabric.Polygon & CustomFabricProps;
//   export type CustomFabricIText = fabric.IText & { id: string };
//   export type CustomFabricPath = fabric.Path & { id: string };
//   export type Controls=fabric.Control & {pointIndex:any};
  //export class FabricControl =new fabric['Control'] as any